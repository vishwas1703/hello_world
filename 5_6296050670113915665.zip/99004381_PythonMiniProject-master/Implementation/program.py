"""
This program is checked for pylint
author - Divya sri
date - 5th june 2021
time - 8:30 pm
"""
import openpyxl
from openpyxl import Workbook
wb = openpyxl.load_workbook("Excel.xlsx")
sheets = wb.sheetnames
length = len(sheets)
sheet = wb["semester marks"]
row = sheet.max_row
column = sheet.max_column


def finding(num):
    """
     :param num:
    :return count:
    """
    count = 0
    for j in range(1, row+1):
        for k in range(1, column+1):
            case = mainSheet.cell(j, k).value
            if num == case:
                count = j
    return count


def checking(word):
    """
    :param word:
    :return depends:
    """
    term = "sorry"
    for number in range(0, length):
        if word == sheets[number]:
            return 80
    return term


print("The ps.numbers in excel are:", end=" ")
for var in range(2, row+1):
    print(sheet.cell(var, 1).value, end=',')
ps_no = int(input("\nChoose one ps.number from them:"))
print("The sheets in excel are:", end=" ")
for i in range(0, length):
    print(sheets[i], end=',')
sh = input("\nChoose one sheet from them:")
try:
    val = checking(sh)
    cal = 80 + val
except TypeError:
    print("Enter correct sheet")
else:
    row = sheet.max_row
    column = sheet.max_column
    mainSheet = wb[sh]
    cellValue = finding(ps_no)
    my_list = []
    wo = Workbook()
    wo['Sheet'].title = "Extracted data"
    sheet_1 = wo.active
    for g in range(1, column + 1):
        variable_1 = mainSheet.cell(1, g).value
        sheet_1.cell(1, g).value = variable_1
    for r in range(1, column + 1):
        variable = mainSheet.cell(cellValue, r).value
        sheet_1.cell(2, r).value = variable
    wo.save("Output_excel.xlsx")
