# 99004381_PythonMiniProject
---
![Excel-Logo](https://user-images.githubusercontent.com/84493363/120977674-39de7e00-c791-11eb-9aa8-847a0e2e7bff.png)
---
## Challenges Faced
|S.No|Description|
|--|--|
|1.|Retrieving the data from an Excel|
|2.|Appending the data into new Excel|
## Reference
1.https://youtu.be/nsKNPHJ9iPc

2.https://realpython.com/openpyxl-excel-spreadsheets-python/

